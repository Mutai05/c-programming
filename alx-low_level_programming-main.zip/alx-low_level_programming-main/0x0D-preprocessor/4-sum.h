#ifndef SUM_MACRO_H
#define SUM_MACRO_H

#define SUM(x, y) ((x) + (y))

#endif /* SUM_MACRO_H */
