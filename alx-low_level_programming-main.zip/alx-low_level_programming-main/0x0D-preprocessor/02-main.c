#include <stdio.h>

int main(void)
{
    printf("%s\n", __FILE__);
    return (0);
}
