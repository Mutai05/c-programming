/**
 * string_toupper - funtion that convert from lower to upper
 * @str: Address of the string
 * Return: The uppercase str address
 */

char *string_toupper(char *str)
{
	int i;

	for (i = 0; str[i] != '\0'; i++)
	{
		if (str[i] >= 97 && str[i] <= 122)
			str[i] -= 32;
	}
	return (str);
}
